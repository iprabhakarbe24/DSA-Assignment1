#include<iostream>
#include<string.h>
using namespace std;
int main(){
    char s[50];
    cout<<"enter string:"<<endl;
    cin>>s;
    strrev(s);
    cout<<"reversed string: "<<s<<endl;
}
